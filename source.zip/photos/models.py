from django.db import models


class Photo(models.Model):
    title = models.CharField(max_length=255)
    url = models.URLField(max_length=2048)

    def __str__(self):
        return self.title
