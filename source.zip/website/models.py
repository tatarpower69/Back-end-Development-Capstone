from django.db import models
class Concert(models.Model):
    band=models.CharField(max_length=100)
    venue=models.CharField(max_length=100)
    date=models.DateField()
    def __str__(self):return f'{self.band} at {self.venue}'
