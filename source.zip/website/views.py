import requests
from django.conf import settings
from django.shortcuts import render
from .models import Concert
def remote(url, fallback):
 try:
    response=requests.get(url,timeout=2);response.raise_for_status();return response.json()
 except requests.RequestException:return fallback
def home(request):return render(request,'home.html')
def songs(request):
 data=remote(settings.SONGS_URL+'/songs',[{'id':1,'title':'Yellow','artist':'Coldplay','lyrics':'Look at the stars'},{'id':2,'title':'Believer','artist':'Imagine Dragons','lyrics':'First things first'}])
 return render(request,'songs.html',{'songs':data})
def photos(request):
 data=remote(settings.PICTURES_URL+'/pictures',[{'id':1,'title':'Band rehearsal','url':'https://picsum.photos/id/250/800/500'}])
 return render(request,'photos.html',{'photos':data[:1]})
def concerts(request):
 data=list(Concert.objects.all())
 if not data:data=[{'band':'Coldplay','venue':'Astana Arena','date':'2026-11-20'},{'band':'Imagine Dragons','venue':'Music Hall','date':'2026-12-12'}]
 return render(request,'concerts.html',{'concerts':data})
