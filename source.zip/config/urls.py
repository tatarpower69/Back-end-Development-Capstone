from django.contrib import admin
from django.urls import path
from website import views
urlpatterns=[path('admin/',admin.site.urls),path('',views.home,name='home'),path('songs/',views.songs,name='songs'),path('photos/',views.photos,name='photos'),path('concerts/',views.concerts,name='concerts')]
