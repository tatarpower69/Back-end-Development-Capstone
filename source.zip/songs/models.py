from django.db import models


class Song(models.Model):
    title = models.CharField(max_length=255)
    artist = models.CharField(max_length=255)
    lyrics = models.TextField(blank=True)

    def __str__(self):
        return f"{self.title} - {self.artist}"
